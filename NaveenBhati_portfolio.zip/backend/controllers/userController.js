import User from "../models/userModel.js";
import express from 'express'
import asyncHandler from 'express-async-handler'
const router = express.Router()

router.post('/', asyncHandler(async (req, res) => {
    const { name, email, message } = req.body
    const userResponse = await User.create({
        name,
        email,
        message
    })
    if (userResponse) {
        res.status(201).json({
            name: userResponse.name,
            email: userResponse.email,
            message: userResponse.message
        })
    } else {
        res.status(400)
        throw new Error("Invalid Response")
    }
}))



export default router