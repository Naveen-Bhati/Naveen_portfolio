const users = [
    {
        name: 'Admin user',
        email: 'admin@test.com',
        message: 'Hi Naveen Bhati'

    }
]

export default users;